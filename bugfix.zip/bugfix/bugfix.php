<?php
/**
* Plugin Name: Bug Fix
* Plugin URI: https://www.viserx.com/
* Description: This is the very first plugin I ever created.
* Version: 1.1.0
* Author: Jahid
* Author URI: http://www.viserx.com/
**/


// Create a new table for Activation

function bugfix_table(){

  global $wpdb;
  $charset_collate = $wpdb->get_charset_collate();
  $tablename = $wpdb->prefix."bugfix_header_footer";
  $sql = "CREATE TABLE $tablename (
  id mediumint(11) NOT NULL AUTO_INCREMENT,
  header TEXT NULL,
  body TEXT NULL,
  footer TEXT NULL,
  PRIMARY KEY  (id)
  ) $charset_collate;";
  require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
  dbDelta( $sql );

}
register_activation_hook( __FILE__, 'bugfix_table' );

// Delete a table for Deactivation

function delete_bugfix_table() {

    global $wpdb;
    $table_name= $wpdb->prefix.'bugfix_header_footer';
    $sql = "DROP TABLE IF EXISTS $table_name";
    $wpdb->query($sql);
    delete_option("devnote_plugin_db_version");

}
register_deactivation_hook( __FILE__, 'delete_bugfix_table' );

// Add menu in Deshboard

function customplugin_menu() {
  add_menu_page("Header Footer", "Header Footer","manage_options", "bugfix_header_footer", "bugfix_deshboard","dashicons-editor-code");
}
add_action("admin_menu", "customplugin_menu");

function bugfix_deshboard(){
  include "bugfix_deshboard.php";
}

//css Added For Bugfix

 function add_my_css_and_my_js_files(){
    wp_enqueue_style( 'bugfix-css', plugins_url('/css/bugfix.css', __FILE__), false, 'all');
}
add_action('admin_enqueue_scripts', "add_my_css_and_my_js_files");

//Header Content Showing
add_action('wp_head', 'bugfix_header_scripts');
function bugfix_header_scripts(){
  global $wpdb;
  $ttablename = $wpdb->prefix."bugfix_header_footer";
  $check_data = $wpdb->get_row("SELECT * FROM ".$ttablename." ");
  if(!empty($check_data->header)){
    echo $check_data->header;
  }
}


//Footer Content Showing
add_action('wp_footer', 'bugfix_footer_scripts');
function bugfix_footer_scripts(){
  global $wpdb;
  $ttablename = $wpdb->prefix."bugfix_header_footer";
  $check_data = $wpdb->get_row("SELECT * FROM ".$ttablename." ");
  if(!empty($check_data->footer)){
    echo $check_data->footer;
  }
}

//Body Content Showing
function bugfix_body_scripts(){
  global $wpdb;
  $ttablename = $wpdb->prefix."bugfix_header_footer";
  $check_data = $wpdb->get_row("SELECT * FROM ".$ttablename." ");
  if(!empty($check_data->body)){
    echo $check_data->body;
  }
}
add_action('wp_body_open', 'bugfix_body_scripts');
