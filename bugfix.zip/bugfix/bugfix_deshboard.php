<?php

global $wpdb;

// Add Data

if(isset($_POST['but_submit'])){

  $headers = $_POST['txt_header'];
  $body = $_POST['txt_body'];
  $footer = $_POST['txt_footer'];
  $tablename = $wpdb->prefix."bugfix_header_footer";

  if($headers || $body || $footer){

      $all_data_check = $wpdb->get_row("SELECT * FROM ".$tablename." ");
      if(empty($all_data_check)){
       $insert_sql = "INSERT INTO ".$tablename."(footer,header,body) values('".$footer."','".$headers."','".$body."') ";
       $wpdb->query($insert_sql);
       echo "<div class='successfully-message'><h3>Sucessfully Data Added</h3></div>";
      }else{
        $insert_sql = "UPDATE ".$tablename." SET footer='$footer',header='$headers', body='$body' WHERE id='$all_data_check->id'";
       $wpdb->query($insert_sql);
       echo "<div class='successfully-message'><h3>Sucessfully Data Updated</h3></div>";
      }

   }
}

$ttablename = $wpdb->prefix."bugfix_header_footer";
$check_data = $wpdb->get_row("SELECT * FROM ".$ttablename." ");

?>


<div class="bugfix-box">
<h1><?php _e("Bug Fix Deshboard"); ?></h1>
<form method='post' action=''>
  <table>
    <tr>
      <td><label for=""><?php _e("Header Content"); ?> <small><?php _e("(Add Your Script in your Header)"); ?></small></label></td>
    </tr>
    <tr>
      <td><textarea name='txt_header'><?php if(!empty($check_data->header)){ echo $check_data->header; } ?></textarea></td>
    </tr>
    <tr>
     <td><label for=""><?php _e("Body Content"); ?> <small><?php _e("(Add Your Script in your Body)"); ?></small></label></td>
    </tr>
    <tr>
      <td><textarea name='txt_body' ><?php if(!empty($check_data->body)){ echo $check_data->body; } ?></textarea></td>
    </tr>
    <tr>
     <td><label for=""><?php _e("Footer Content"); ?> <small><?php _e("(Add Your Script in your Footer)"); ?></small></label></td>
    </tr>
    <tr> 
      <td><textarea name='txt_footer' ><?php if(!empty($check_data->footer)){ echo $check_data->footer; } ?></textarea></td>
    </tr>
    <tr>
     <td><input type='submit' name='but_submit' value='Submit'></td>
    </tr>
 </table>
</form>
</div>